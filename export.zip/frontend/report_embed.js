// frontend/report_embed.js
// Lightweight client-side renderer for the Strategic Negotiation Report.
// Usage patterns:
//
// 1) Dispatch an event after receiving the report JSON from backend:
//    fetch('/questionnaire/report', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload)})
//      .then(r=>r.json())
//      .then(data => window.dispatchEvent(new CustomEvent('np:renderReport', { detail: data })));
//
// 2) Or call window.renderNegotiationReport(data, {container:'#report-root'})
//
// It builds a modal by default if no container supplied.

(function(){
  function el(tag, attrs={}, children=[]){
    const n = document.createElement(tag);
    Object.entries(attrs||{}).forEach(([k,v])=>{
      if(k === "class") n.className = v;
      else if(k === "style") n.setAttribute("style", v);
      else n.setAttribute(k, v);
    });
    (children||[]).forEach(c => {
      if(typeof c === "string") n.appendChild(document.createTextNode(c));
      else if(c) n.appendChild(c);
    });
    return n;
  }

  function bar(label, v){
    const pct = Math.round((Math.max(0, Math.min(1, v))) * 100);
    const wrap = el("div", {class:"np-row", style:"margin:6px 0"});
    wrap.appendChild(el("div", {class:"np-muted"}, [label]));
    const bar = el("div", {class:"np-bar"});
    const fill = el("span", {style:`width:${pct}%`});
    bar.appendChild(fill);
    wrap.appendChild(bar);
    return wrap;
  }

  function cssOnce(){
    if(document.getElementById("np-report-css")) return;
    const style = el("style", {id:"np-report-css"});
    style.textContent = `
      .np-modal{position:fixed; inset:0; display:grid; place-items:center; z-index:60;
        background:rgba(0,0,0,.55)}
      .np-card{width:min(900px, 92vw); max-height:86vh; overflow:auto;
        background:linear-gradient(180deg, rgba(255,255,255,.06), rgba(255,255,255,.03));
        border:1px solid rgba(255,255,255,.15); color:#fff; border-radius:18px; padding:18px;
        box-shadow: 0 15px 40px rgba(0,0,0,.45); font-family: ui-sans-serif, system-ui, Segoe UI, Roboto}
      .np-header{display:flex; align-items:center; justify-content:space-between; gap:10px; margin-bottom:8px}
      .np-title{font-weight:900; letter-spacing:.2px}
      .np-muted{color:#b8c0d0; font-size:13px}
      .np-grid{display:grid; gap:12px; grid-template-columns: 1fr 1fr}
      @media(max-width:900px){ .np-grid{grid-template-columns:1fr} }
      .np-box{background:rgba(255,255,255,.05); border:1px solid rgba(255,255,255,.12); border-radius:14px; padding:14px}
      .np-bar{height:10px; background:rgba(255,255,255,.12); border-radius:999px; overflow:hidden}
      .np-bar>span{display:block; height:100%; background:linear-gradient(90deg,#8a7cff,#22d3ee); width:0}
      .np-row{display:flex; flex-direction:column}
      .np-tags{display:flex; gap:8px; flex-wrap:wrap}
      .np-tag{font-size:12px; padding:4px 8px; border-radius:999px; background:rgba(138,124,255,.2); border:1px solid rgba(255,255,255,.2)}
      .np-links a{display:inline-block; padding:8px 10px; border-radius:12px; background:rgba(255,255,255,.06); border:1px solid rgba(255,255,255,.12); color:#fff; text-decoration:none; margin-right:8px}
      .np-footer{display:flex; justify-content:flex-end; margin-top:10px}
      .np-btn{padding:10px 14px; border-radius:12px; border:1px solid rgba(255,255,255,.16); background:rgba(255,255,255,.08); color:#fff; cursor:pointer}
    `;
    document.head.appendChild(style);
  }

  function buildReportView(data){
    const card = el("div", {class:"np-card"});

    // Header
    const header = el("div", {class:"np-header"});
    header.appendChild(el("div", {}, [
      el("div", {class:"np-title"}, [data.title || "Strategic Negotiation Report"]),
      el("div", {class:"np-muted"}, [`Built ${data.build || ""} • ${new Date(data.created_at||Date.now()).toLocaleString()}`]),
    ]));
    const closeBtn = el("button", {class:"np-btn", "data-close":"1"}, ["Close"]);
    header.appendChild(closeBtn);
    card.appendChild(header);

    // Summary
    const summary = el("div", {class:"np-box"});
    summary.appendChild(el("div", {style:"font-weight:800; margin-bottom:6px"}, ["Summary"]));
    summary.appendChild(el("div", {class:"np-grid"}, [
      el("div", {}, [
        el("div", {class:"np-muted"}, ["Primary goal"]),
        el("div", {}, [data.summary?.primary_goal || "—"]),
        el("div", {class:"np-muted", style:"margin-top:8px"}, ["Stance"]),
        el("div", {}, [data.summary?.stance || "—"]),
      ]),
      el("div", {}, [
        el("div", {class:"np-muted"}, ["Priority lever"]),
        el("div", {}, [data.summary?.priority_lever || "—"]),
        el("div", {class:"np-muted", style:"margin-top:8px"}, ["Salary range"]),
        el("div", {}, [
          (data.salary_range
            ? `${data.salary_range.min}-${data.salary_range.max} ${data.salary_range.currency} (target ${data.salary_range.target})`
            : "—")
        ]),
      ]),
    ]));
    card.appendChild(summary);

    // Tactics
    const tactics = el("div", {class:"np-box", style:"margin-top:12px"});
    tactics.appendChild(el("div", {style:"font-weight:800; margin-bottom:6px"}, ["Tactics"]));
    const tagWrap = el("div", {class:"np-tags"});
    (data.tactics||[]).forEach(t => tagWrap.appendChild(el("div", {class:"np-tag"}, [t])));
    tactics.appendChild(tagWrap);
    card.appendChild(tactics);

    // Scores
    const scores = el("div", {class:"np-box", style:"margin-top:12px"});
    scores.appendChild(el("div", {style:"font-weight:800; margin-bottom:6px"}, ["Scores"]));
    (data.score_blocks||[]).forEach(s => scores.appendChild(bar(s.label, s.value)));
    card.appendChild(scores);

    // Links
    const links = el("div", {class:"np-box", style:"margin-top:12px"});
    links.appendChild(el("div", {style:"font-weight:800; margin-bottom:6px"}, ["References"]));
    const lwrap = el("div", {class:"np-links"});
    (data.links||[]).forEach(o=>{
      const a = el("a", {href:o.url, target:"_blank", rel:"noopener"}, [o.label || o.url]);
      lwrap.appendChild(a);
    });
    links.appendChild(lwrap);
    card.appendChild(links);

    // Footer
    const foot = el("div", {class:"np-footer"});
    const copyBtn = el("button", {class:"np-btn"}, ["Copy JSON"]);
    copyBtn.addEventListener("click", ()=> {
      navigator.clipboard.writeText(JSON.stringify(data, null, 2));
    });
    foot.appendChild(copyBtn);
    card.appendChild(foot);

    return card;
  }

  function openModal(view){
    const modal = el("div", {class:"np-modal", id:"np-modal"});
    modal.appendChild(view);
    modal.addEventListener("click", (e)=>{
      if(e.target.id === "np-modal" || e.target.dataset.close === "1"){
        modal.remove();
      }
    });
    document.body.appendChild(modal);
  }

  function renderNegotiationReport(data, opts){
    cssOnce();
    const view = buildReportView(data);
    const container = opts && opts.container ? document.querySelector(opts.container) : null;
    if(container){
      container.innerHTML = "";
      container.appendChild(view);
    }else{
      openModal(view);
    }
  }

  // Expose
  window.renderNegotiationReport = renderNegotiationReport;

  // Auto-listen for event
  window.addEventListener("np:renderReport", (e)=>{
    renderNegotiationReport(e.detail);
  });
})();
