// frontend/app.js — SPA controller with business-grade polish (English only)

const API_BASE = ""; // same-origin

/* ------------- Templates ------------- */
const Templates = {
  pageShell: (title, subtitle, content) => `
    <div class="view-enter">
      <h1 class="page-title">${title}</h1>
      <p class="page-subtitle">${subtitle}</p>
      ${content}
    </div>`,

  dashboard: (data) => {
    const kpiHtml = data.kpis.map(k => {
      if (k.type === "text") {
        return `
          <div class="card kpi-card elevate" data-aos="fade-up">
            <div class="kpi-value">${k.text}</div>
            <div class="kpi-label">${k.label}</div>
          </div>`;
      }
      const decimals = k.decimals ?? 0;
      const suffix = k.suffix ?? "";
      return `
        <div class="card kpi-card elevate" data-aos="fade-up">
          <div class="kpi-value" data-animate="count" data-end="${k.value}" data-decimals="${decimals}" data-suffix="${suffix}">0${suffix}</div>
          <div class="kpi-label">${k.label}</div>
        </div>`;
    }).join("");

    const skillsHtml = data.skills_breakdown.map(s => `
      <div class="skill-item">
        <div class="skill-label">${s.skill}</div>
        <div class="skill-bar"><span data-animate="bar" data-width="${s.score}"></span></div>
        <div class="skill-score">${s.score}%</div>
      </div>
    `).join("");

    return Templates.pageShell(
      "Dashboard",
      "A precise overview of your performance and negotiation skills.",
      `
      <div class="grid lg:grid-cols-4 gap-6">
        ${kpiHtml}
      </div>
      <div class="card elevate" data-aos="fade-up" style="margin-top:1.5rem">
        <h2 style="font-size:1.5rem;margin-bottom:.6rem">Negotiation skills</h2>
        <div class="skills-container">${skillsHtml}</div>
      </div>`
    );
  },

  strategy: () => Templates.pageShell(
    "Strategy engine",
    "Answer a tailored questionnaire to generate a professional strategy report.",
    `
    <div class="card stepper-container elevate" data-aos="fade-up">
      <div id="strategy-stepper">
        <div class="text-center p-8"><p>Loading questionnaire…</p><div class="loading-spinner"></div></div>
      </div>
    </div>
    <div id="report-container" style="display:none;margin-top:1.5rem">
      <div class="card elevate" data-aos="fade-up">
        <h2 class="page-title">Your report is ready</h2>
        <iframe id="report-iframe" title="Negotiation Report"></iframe>
      </div>
    </div>`
  ),

  practice: (scenarios) => Templates.pageShell(
    "Practice scenarios",
    "Choose a scenario and start focused practice.",
    `
    <div class="grid lg:grid-cols-3 gap-6">
      ${scenarios.map(s => `
        <div class="card practice-card elevate" data-aos="fade-up">
          <div>
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:.5rem">
              <h3 style="margin:0">${s.title}</h3>
              <span class="badge ${s.type === 'Hard' ? 'hard' : (s.type === 'Medium' ? 'medium' : 'easy')}">${s.type}</span>
            </div>
            <p style="color:var(--muted);font-size:.95rem;margin-bottom:1rem">Skills: ${s.skills.join(", ")}</p>
          </div>
          <div>
            <div class="card-footer">
              <span><i class="fa fa-clock" style="margin-left:.5rem"></i>${s.duration}</span>
              <span><i class="fa fa-users" style="margin-left:.5rem"></i>${s.participants} participants</span>
            </div>
            <button class="btn" style="width:100%;margin-top:1rem">Start practice</button>
          </div>
        </div>
      `).join("")}
    </div>`
  ),

  coach: () => Templates.pageShell(
    "AI Coach",
    "Chat with your personal negotiation coach for instant tips.",
    `
    <div class="card chat-container">
      <div id="chat-box">
        <div class="bubble ai">Hi! What would you like to focus on today?</div>
      </div>
      <div class="chat-input-area">
        <input id="chat-input" type="text" placeholder="Type your question…">
        <button id="chat-send-btn" class="btn">Send</button>
      </div>
    </div>`
  ),

  analytics: (data) => Templates.pageShell(
    "Performance analytics",
    "Get insights and recommendations for continuous improvement.",
    `
    <div class="grid md:grid-cols-2 gap-6">
      <div class="card elevate" data-aos="fade-up">
        <h2 style="margin-bottom:.6rem">Recent scores</h2>
        <div style="display:flex;flex-direction:column;gap:.75rem">
          ${data.performance_scores.map(i => `
            <div class="kpi-list-item">
              <span>${i.label}</span>
              <span class="kpi-score">${i.score}</span>
            </div>
          `).join("")}
        </div>
      </div>
      <div class="card elevate" data-aos="fade-up">
        <h2 style="margin-bottom:.6rem">Recommendations</h2>
        <div style="display:flex;flex-direction:column;gap:1rem">
          ${data.improvement_suggestions.map(i => `
            <div class="suggestion-item">
              <h4 style="font-weight:900;margin-bottom:.25rem">${i.title}</h4>
              <p style="color:var(--muted);font-size:.95rem">${i.description}</p>
            </div>
          `).join("")}
        </div>
      </div>
    </div>`
  ),

  settings: () => Templates.pageShell(
    "Settings",
    "Adjust the app to your needs.",
    `
    <div class="card" style="max-width:820px;margin:auto">
      <div class="setting-row">
        <div>
          <div style="font-weight:900">Interface language</div>
          <div style="color:var(--muted);font-size:.95rem">Current: English</div>
        </div>
        <button class="btn secondary">Change</button>
      </div>
      <div class="setting-row">
        <div>
          <div style="font-weight:900">Notifications</div>
          <div style="color:var(--muted);font-size:.95rem">Get reminders about your progress</div>
        </div>
      </div>
    </div>`
  ),
};

/* ------------- Questionnaire logic ------------- */
let questionnaireSpec = null;
let currentPhaseIndex = 0;
let userAnswers = {};

async function loadQuestionnaire(){
  if (questionnaireSpec) return;
  const res = await fetch(`${API_BASE}/questionnaire/schema`);
  if (!res.ok) throw new Error("Failed to load schema");
  questionnaireSpec = await res.json();
}

function renderStrategyStep(){
  const root = document.getElementById("strategy-stepper");
  if (!root || !questionnaireSpec) return;

  const phase = questionnaireSpec.phases[currentPhaseIndex];
  const progress = ((currentPhaseIndex + 1) / questionnaireSpec.phases.length) * 100;

  const questionsHTML = phase.questions.map(q => renderQuestion(q)).join("");

  root.innerHTML = `
    <div class="progress-bar"><div class="progress-bar-inner" style="width:${progress}%"></div></div>
    <h2 class="question-title">${(phase.title || "").replace(/_/g," ")}</h2>
    <p class="page-subtitle">${phase.description || ""}</p>

    <form id="questionnaire-form" style="display:flex;flex-direction:column;gap:1.4rem">
      ${questionsHTML}
    </form>

    <div class="stepper-nav">
      <button id="strategy-back" class="btn secondary" ${currentPhaseIndex===0?'disabled':''}>Back</button>
      <button id="strategy-next" class="btn">${currentPhaseIndex===questionnaireSpec.phases.length-1?'Create report':'Next'}</button>
    </div>
  `;

  // selection highlight
  root.querySelectorAll(".choice-btn").forEach(lbl=>{
    lbl.addEventListener("click", ()=>{
      const input = lbl.querySelector("input");
      if (input?.type === "radio") {
        root.querySelectorAll(`input[name="${input.name}"]`).forEach(r => r.closest("label")?.classList.remove("selected"));
      }
      lbl.classList.toggle("selected", input.checked);
    });
  });

  document.getElementById("strategy-back")?.addEventListener("click", (e)=>{
    e.preventDefault();
    collectAnswers();
    if (currentPhaseIndex>0){ currentPhaseIndex--; renderStrategyStep(); }
  });

  document.getElementById("strategy-next")?.addEventListener("click", async (e)=>{
    e.preventDefault();
    collectAnswers();
    if (currentPhaseIndex < questionnaireSpec.phases.length - 1){
      currentPhaseIndex++; renderStrategyStep();
    } else {
      await finishStrategy();
    }
  });
}

function renderQuestion(q){
  const val = userAnswers[q.id];
  let input = "";
  switch(q.answerType){
    case "single_choice":
      input = `<div class="choices-grid">${
        (q.options||[]).map(opt=>`
          <label class="choice-btn ${val===opt.value?'selected':''}">
            <input type="radio" name="${q.id}" value="${opt.value}" ${val===opt.value?'checked':''}>
            ${opt.label}
          </label>`).join("")
      }</div>`; break;

    case "multiple_choice":
      input = `<div class="choices-grid">${
        (q.options||[]).map(opt=>{
          const checked = Array.isArray(val) && val.includes(opt.value);
          return `<label class="choice-btn ${checked?'selected':''}">
              <input type="checkbox" name="${q.id}" value="${opt.value}" ${checked?'checked':''}>
              ${opt.label}
            </label>`;
        }).join("")
      }</div>`; break;

    case "free_text_limited":
      input = `<textarea name="${q.id}" rows="3" class="form-input" placeholder="${q.ui?.placeholder||''}">${val||''}</textarea>`;
      break;

    case "rating_scale":
      input = `<input class="form-input" type="number" name="${q.id}" min="${q.scaleMin}" max="${q.scaleMax}" value="${val||''}" placeholder="Number between ${q.scaleMin}-${q.scaleMax}">`;
      break;

    default:
      input = `<input class="form-input" type="text" name="${q.id}" value="${val||''}" placeholder="${q.ui?.placeholder||''}">`;
  }
  return `<div><label style="font-weight:800;margin-bottom:.6rem;display:block">${q.question}</label>${input}</div>`;
}

function collectAnswers(){
  const form = document.getElementById("questionnaire-form");
  if (!form) return;
  const formData = new FormData(form);
  const names = new Set(Array.from(form.elements).map(el => el.name).filter(Boolean));

  names.forEach(name => {
    const all = formData.getAll(name);
    if (all.length > 1) userAnswers[name] = all;
    else if (all.length === 1) userAnswers[name] = all[0];
    else {
      const el = form.querySelector(`[name="${name}"]`);
      if (el && el.type === "checkbox") userAnswers[name] = [];
    }
  });
}

async function finishStrategy(){
  const root = document.getElementById("strategy-stepper");
  const wrap = document.getElementById("report-container");
  const iframe = document.getElementById("report-iframe");

  root.innerHTML = `<div class="text-center p-8"><div class="loading-spinner"></div><p style="text-align:center;margin-top:1rem">Generating report…</p></div>`;
  try{
    const res = await fetch(`${API_BASE}/questionnaire/report`,{
      method:"POST",
      headers:{ "Content-Type":"application/json" },
      body: JSON.stringify({ answers: userAnswers })
    });
    if(!res.ok) throw new Error(`Server error: ${res.statusText}`);
    const data = await res.json();
    if (!data.ok) throw new Error(data.reason || "Unknown error");

    const htmlRes = await fetch(data.report_url);
    if(!htmlRes.ok) throw new Error(`Failed to load report: ${htmlRes.statusText}`);
    const html = await htmlRes.text();

    root.style.display = "none";
    wrap.style.display = "block";
    iframe.srcdoc = html;
  }catch(err){
    root.innerHTML = `<div class="card" style="color:var(--bad);text-align:center">Failed to generate report: ${err.message}</div>`;
  }
}

/* ------------- AI Coach ------------- */
async function sendChatMessage(){
  const input = document.getElementById("chat-input");
  const box = document.getElementById("chat-box");
  const msg = (input.value || "").trim();
  if(!msg) return;

  box.insertAdjacentHTML("beforeend", `<div class="bubble me">${msg}</div>`);
  input.value = "";
  box.scrollTop = box.scrollHeight;

  const id = `thinking-${Date.now()}`;
  box.insertAdjacentHTML("beforeend", `<div id="${id}" class="bubble ai"><span class="loading-spinner" style="width:20px;height:20px;margin:0"></span></div>`);
  box.scrollTop = box.scrollHeight;

  try{
    const res = await fetch(`${API_BASE}/coach`,{
      method:"POST",
      headers:{ "Content-Type":"application/json" },
      body: JSON.stringify({ msg })
    });
    const data = await res.json();
    const bubble = document.getElementById(id);
    if (bubble) bubble.textContent = data.reply || "Got it.";
  }catch(e){
    const bubble = document.getElementById(id);
    if (bubble) bubble.textContent = "Error. Please try again later.";
  }
  box.scrollTop = box.scrollHeight;
}

/* ------------- Animations (count-up & bars) ------------- */
function animateOnView(){
  const root = document.getElementById("app-root");
  if(!root) return;

  const nums = [...root.querySelectorAll('[data-animate="count"]')];
  const bars = [...root.querySelectorAll('[data-animate="bar"]')];

  const io = new IntersectionObserver((entries)=>{
    entries.forEach(entry=>{
      if(!entry.isIntersecting) return;
      const el = entry.target;

      if (el.dataset.animate === "count"){
        const end = parseFloat(el.dataset.end || "0");
        const decimals = parseInt(el.dataset.decimals || "0", 10);
        const suffix = el.dataset.suffix || "";
        const start = 0;
        const dur = 900;
        const t0 = performance.now();
        function tick(t){
          const p = Math.min(1, (t - t0)/dur);
          const val = start + (end - start)*p;
          el.textContent = val.toFixed(decimals) + suffix;
          if (p<1) requestAnimationFrame(tick);
        }
        requestAnimationFrame(tick);
        io.unobserve(el);
      }

      if (el.dataset.animate === "bar"){
        const w = parseInt(el.dataset.width || "0", 10);
        el.style.width = w + "%";
        io.unobserve(el);
      }
    });
  }, {threshold: .4});

  nums.forEach(n=>io.observe(n));
  bars.forEach(b=>io.observe(b));
}

/* ------------- SPA Router ------------- */
const app = {
  root: document.getElementById("app-root"),
  navLinks: document.querySelectorAll(".nav-link"),

  mockData: {
    dashboard: {
      kpis: [
        { label: "Total negotiations", value: 47, decimals: 0, suffix: "" },
        { label: "Success rate", value: 78, decimals: 0, suffix: "%" },
        { label: "Average score", value: 8.4, decimals: 1, suffix: "" },
        { label: "Skill level", type: "text", text: "Advanced" },
      ],
      skills_breakdown: [
        { skill: "Communication", score: 85 },
        { skill: "Strategy", score: 72 },
        { skill: "Analysis", score: 90 },
        { skill: "Creativity", score: 68 },
      ],
    },
    practice: [
      { title: "Salary negotiation", type: "Medium", skills: ["Confidence", "Value framing"], duration: "15–20 min", participants: 2 },
      { title: "Real-estate deal", type: "Hard", skills: ["Strategy", "Patience"], duration: "25–30 min", participants: 3 },
      { title: "Business agreement", type: "Easy", skills: ["Creativity", "Active listening"], duration: "10–15 min", participants: 2 },
    ],
    analytics: {
      performance_scores: [
        { label: "Salary negotiation", score: 9.2 },
        { label: "Real-estate deal", score: 7.8 },
        { label: "Business agreement", score: 8.9 },
      ],
      improvement_suggestions: [
        { title: "Use evidence-based arguments", description: "Anchor proposals with quantified outcomes and market data." },
        { title: "Strengthen self-advocacy", description: "Craft a crisp opening and practice delivery." },
      ]
    }
  },

  async loadPage(page){
    this.root.innerHTML = `<div class="loading-spinner"></div>`;
    try{
      switch(page){
        case "dashboard":
          this.root.innerHTML = Templates.dashboard(this.mockData.dashboard);
          animateOnView();
          break;
        case "practice":
          this.root.innerHTML = Templates.practice(this.mockData.practice);
          break;
        case "analytics":
          this.root.innerHTML = Templates.analytics(this.mockData.analytics);
          break;
        case "strategy":
          this.root.innerHTML = Templates.strategy();
          await loadQuestionnaire();
          renderStrategyStep();
          break;
        case "coach":
          this.root.innerHTML = Templates.coach();
          const btn = document.getElementById("chat-send-btn");
          const inp = document.getElementById("chat-input");
          btn?.addEventListener("click", sendChatMessage);
          inp?.addEventListener("keypress", (e)=>{ if(e.key==="Enter") sendChatMessage(); });
          break;
        case "settings":
          this.root.innerHTML = Templates.settings();
          break;
        default:
          this.root.innerHTML = `<div class="card">Not found.</div>`;
      }
    }catch(e){
      this.root.innerHTML = `<div class="card" style="color:var(--bad);text-align:center">Failed to load page: ${e.message}</div>`;
    }
  },

  handleRouteChange(){
    const page = window.location.hash.substring(1) || "dashboard";
    this.navLinks.forEach(a => a.classList.toggle("active", a.dataset.target === page));
    this.loadPage(page);
  },

  init(){
    window.addEventListener("hashchange", ()=>this.handleRouteChange());
    this.handleRouteChange();
  }
};

app.init();
