# backend/app.py
from __future__ import annotations
import json, uuid
from pathlib import Path
from datetime import datetime
from typing import Any, Dict
from flask import Flask, jsonify, request, send_from_directory, make_response, Response
from flask_cors import CORS

# ----- Paths -----
BACKEND_DIR  = Path(__file__).resolve().parent
ROOT_DIR     = BACKEND_DIR.parent
FRONTEND_DIR = ROOT_DIR / "frontend"

BUILD = "negpro-backend-v6"
REPORTS: Dict[str, str] = {}  # report_id -> HTML

def _nocache(resp: Response) -> Response:
    resp.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    resp.headers["Pragma"] = "no-cache"
    resp.headers["Expires"] = "0"
    return resp

def _json(data: Any, code: int = 200) -> Response:
    return _nocache(make_response(jsonify(data), code))

def _find_questionnaire() -> Path | None:
    candidates = [
        ROOT_DIR / "questionnaire.json",
        BACKEND_DIR / "questionnaire.json",
        FRONTEND_DIR / "questionnaire.json",
    ]
    for p in candidates:
        if p.exists():
            return p
    return None

# optional: try to use your engine if present
def _make_engine():
    try:
        from .engine_entrypoint import QuestionnaireEngine  # your integration
        return QuestionnaireEngine(debug=False)
    except Exception:
        return None

ENGINE = _make_engine()

def create_app() -> Flask:
    app = Flask(__name__, static_folder=None)
    CORS(app)
    app.config["JSON_AS_ASCII"] = False
    app.config["SEND_FILE_MAX_AGE_DEFAULT"] = 0

    # ---------- Static ----------
    @app.get("/")
    def index():
        idx = FRONTEND_DIR / "index.html"
        if not idx.exists():
            return _json({"error": f"{idx} not found"}, 404)
        return _nocache(send_from_directory(str(FRONTEND_DIR), "index.html"))

    @app.get("/frontend/<path:filename>")
    def serve_frontend(filename: str):
        file_path = FRONTEND_DIR / filename
        if not file_path.exists():
            return _json({"error": f"frontend file not found: {filename}"}, 404)
        return _nocache(send_from_directory(str(FRONTEND_DIR), filename))

    # Fallbacks for legacy paths
    @app.get("/app.js")
    def app_js_fallback():
        f = FRONTEND_DIR / "app.js"
        if not f.exists():
            return _json({"error": "frontend/app.js not found"}, 404)
        return _nocache(send_from_directory(str(FRONTEND_DIR), "app.js"))

    @app.get("/report_embed.js")
    def report_embed_js_fallback():
        f = FRONTEND_DIR / "report_embed.js"
        if not f.exists():
            return _json({"error": "frontend/report_embed.js not found"}, 404)
        return _nocache(send_from_directory(str(FRONTEND_DIR), "report_embed.js"))

    # ---------- Health ----------
    @app.get("/health")
    def health():
        return _json({"ok": True, "build": BUILD, "ts": datetime.utcnow().isoformat() + "Z"})

    # ---------- Demo data for dashboard / analytics ----------
    @app.get("/metrics")
    def metrics():
        return _json({
            "total": 47,
            "success_rate": 0.78,
            "avg_score": 8.4,
            "competencies": {"communication": .85, "strategy": .72, "analysis": .90, "creativity": .68}
        })

    @app.get("/insights/latest")
    def insights_latest():
        return _json({
            "recent": [
                {"label": "Salary Raise", "score": 9.2},
                {"label": "Real-Estate Deal", "score": 7.8},
                {"label": "Business Agreement", "score": 8.9},
            ],
            "recommendations": [
                {"title": "Sharpen evidence", "desc": "Use quantified results and impact phrasing."},
                {"title": "Strengthen self-advocacy", "desc": "Script a firm opener and practice delivery."},
                {"title": "Refine tone control", "desc": "Adjust assertiveness by counterpart type."},
            ],
        })

    @app.post("/coach")
    def coach():
        msg = (request.get_json(force=True) or {}).get("msg", "").lower()
        if "salary" in msg:
            rep = "Use market data to anchor. What range fits your role and city?"
        elif "deadline" in msg:
            rep = "Deadlines add leverage. Define a timebox and a BATNA."
        else:
            rep = "Share one constraint and one opportunity you have now."
        return _json({"reply": rep})

    # ---------- Questionnaire ----------
    @app.get("/questionnaire/schema")
    def questionnaire_schema():
        path = _find_questionnaire()
        if not path:
            return _json({"error": "questionnaire.json not found in project root/backend/frontend"}, 404)
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            return _json(data)
        except Exception as e:
            return _json({"error": f"failed reading questionnaire.json: {e}"}, 500)

    @app.post("/questionnaire/report")
    def questionnaire_report():
        payload = request.get_json(force=True) or {}
        answers = payload.get("answers") or payload.get("questionnaire") or {}
        if not isinstance(answers, dict):
            return _json({"ok": False, "reason": "answers must be an object"}, 400)

        # Use your engine if available; otherwise fallback to a simple HTML.
        html: str
        if ENGINE:
            try:
                out = ENGINE.run(answers)  # expected: {"status":"ok","html":"..."}
                if out.get("status") != "ok":
                    return _json({"ok": False, "reason": out.get("reason", "engine error")}, 500)
                html = out.get("html") or "<h1>Report</h1><p>No HTML returned by engine.</p>"
            except Exception as e:
                return _json({"ok": False, "reason": f"engine failed: {e}"}, 500)
        else:
            # very simple fallback
            rows = "".join(f"<tr><td>{k}</td><td>{json.dumps(v, ensure_ascii=False)}</td></tr>" for k, v in answers.items())
            html = f"""
            <!doctype html><html lang="en"><head>
              <meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
              <title>Negotiation Report</title>
              <style>body{{font-family:system-ui,Segoe UI,Roboto,Arial;padding:24px;background:#0b1220;color:#e8ecff}}
              .card{{background:#151b2d;border:1px solid #28304a;border-radius:14px;padding:18px}}
              table{{width:100%;border-collapse:collapse}}td,th{{border-bottom:1px solid #2b3555;padding:8px;text-align:right}}</style>
            </head><body>
              <h1>Strategy Report</h1>
              <div class="card">
                <h3>Answers snapshot</h3>
                <table><thead><tr><th>Id</th><th>Value</th></tr></thead><tbody>{rows}</tbody></table>
              </div>
              <script src="/report_embed.js"></script>
            </body></html>
            """

        rid = uuid.uuid4().hex[:12]
        REPORTS[rid] = html
        return _json({"ok": True, "report_id": rid, "report_url": f"/report/{rid}"}, 201)

    @app.get("/report/<rid>")
    def report_page(rid: str):
        html = REPORTS.get(rid)
        if not html:
            return _json({"error": "report not found"}, 404)
        resp = make_response(html, 200)
        resp.mimetype = "text/html"
        return _nocache(resp)

    return app
